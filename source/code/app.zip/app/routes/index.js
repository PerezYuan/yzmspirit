var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.html', { title: 'Express' });
});

const multiparty = require('connect-multiparty');
const path = require('path');
let uploadDir = path.resolve(__dirname, '../temp');
let multipartMiddleware = multiparty({uploadDir});
 
router.post('/upload', multipartMiddleware, function(req, res, next) {
    console.log(req.files);
    const qiniu = require("qiniu");
 
    //需要填写你的 Access Key 和 Secret Key
    qiniu.conf.ACCESS_KEY = 'Access Key';
    qiniu.conf.SECRET_KEY = 'Secret Key';
 
    //要上传的空间
    bucket = 'tinashy';
  
    //构建上传策略函数
    function uptoken(bucket, key) {
        let putPolicy = new qiniu.rs.PutPolicy(bucket+":"+key);
        return putPolicy.token();
    }
  
    //构造上传函数
    function uploadFile(uptoken, key, localFile, resolve, reject) {
        let extra = new qiniu.io.PutExtra();
        qiniu.io.putFile(uptoken, key, localFile, extra, function(err, ret) {
            if(!err) {
                // 上传成功， 处理返回值
                resolve(localFile);
                console.log(ret.hash, ret.key, ret.persistentId);
            } else {
                // 上传失败， 处理返回代码
                reject(err);
            }
        });
    }
 
    // 构造Promise数组
    let promiseArr = [];
    for (index in req.files) {
        let p = new Promise((resolve, reject) => {
            //上传到七牛后保存的文件名
            key = req.files[index].originalFilename;
            //生成上传 Token
            token = uptoken(bucket, key);
      
            //要上传文件的本地路径
            filePath = req.files[index].path;
     
            //调用uploadFile上传
            uploadFile(token, key, filePath, resolve, reject);
        })

        promiseArr.push(p);
    }
    // 所有异步执行完成之后返回成功
    let pAll = Promise.all(promiseArr);
    pAll.then((localFile) => {
        console.log(localFile);
        res.json({code: 1})
    }, (err) => {
        console.log(err);
        res.json({code: 0, msg: '上传失败'});
    })
});

module.exports = router;